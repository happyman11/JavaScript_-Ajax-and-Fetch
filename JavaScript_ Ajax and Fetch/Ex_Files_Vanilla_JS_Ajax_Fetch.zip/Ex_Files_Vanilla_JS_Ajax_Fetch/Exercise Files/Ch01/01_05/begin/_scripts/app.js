'use strict';

const url = 'https://us-street.api.smartystreets.com/street-address?auth-id=36f5c695-e461-e30b-43af-893dd13840c9&auth-token=KyJaHfeiDJNCdfym0ClU&candidates=10&street=86%20Frontage%20Road&city=Belmont&state=MA';